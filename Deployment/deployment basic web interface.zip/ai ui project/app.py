from flask import Flask, render_template, request
import requests

app = Flask(__name__)

# Replace these URLs with your teammates’ actual API endpoints
GRU_API_URL = "http://localhost:8000/gru"  # placeholder
LSTM_API_URL = "http://localhost:8000/lstm"
CNN_API_URL = "http://localhost:8000/cnn"
TRANSFER_API_URL = "http://localhost:8000/transfer"

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict_text', methods=["POST"])
def predict_text():
    input_text = request.form["text_input"]
    model_type = request.form["model_type"]

    api_url = GRU_API_URL if model_type == "GRU" else LSTM_API_URL
    response = requests.post(api_url, json={"text": input_text})
    result = response.json()

    return render_template("index.html", prediction=result["prediction"])

@app.route('/predict_image', methods=["POST"])
def predict_image():
    file = request.files["image_file"]
    model_type = request.form["image_model_type"]
    api_url = CNN_API_URL if model_type == "CNN" else TRANSFER_API_URL

    files = {"file": file.read()}
    response = requests.post(api_url, files=files)
    result = response.json()

    return render_template("index.html", prediction=result["prediction"])

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
